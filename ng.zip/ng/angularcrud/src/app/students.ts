export class Students {
    sId: any;
    id: any;
}
