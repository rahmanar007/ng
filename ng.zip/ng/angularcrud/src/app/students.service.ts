import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Students } from './students';

@Injectable({
  providedIn: 'root'
})
export class StudentsService {

  constructor(private http: HttpClient ) { }

  getStudents() {
    return this.http.get<Students[]>('http://localhost/ng/phpcrud/list.php')
  }

  deleteStudents(sId:number) {
    return this.http.delete<Students[]>('http://localhost/ng/phpcrud/delete.php?sId=' +sId);
  }

  createStudents(student:Students) {
    return this.http.post('http://localhost/ng/phpcrud/insert.php', student);
  }

  getStudentById(Id:number) {
    return this.http.get<Students[]>('http://localhost/ng/phpcrud/getStudentId.php?Id=' +Id);
  } 


  updateStudent(student:Students) {
    return this.http.put('http://localhost/ng/phpcrud/update.php' + '?id=' + student.sId, student);

  }
}
