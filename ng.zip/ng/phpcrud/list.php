<?php 
require 'confiq.php';


//Listing Students Detail
$students =[];
$sql = "SELECT * FROM students";


if($rslt = mysqli_query($con,$sql)) {
    $cr = 0;
    while($row = mysqli_fetch_assoc($rslt)) {
        $students[$cr]['sId'] = $row['sId'];
        $students[$cr]['sName'] = $row['sName'];
        $students[$cr]['email'] = $row['email'];
        $cr++;
    }
    echo json_encode($students);
    //print_r($students);

}
else {
    http_response_code(404);
}
?>