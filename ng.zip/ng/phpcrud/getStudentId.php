<?php 
require 'confiq.php';


//get Students Detail
$id = $_GET['Id']; 



$sql = "SELECT * FROM students WHERE sId=$id LIMIT 1";


$result = mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);
    echo $json = json_encode($row);
exit;


?>