<?php 
require 'confiq.php';

//Update Student Details 
$postData = file_get_contents("php://input");


if(isset($postData) && !empty($postData)) {
    $_REQUEST = json_decode($postData);

    $sId = mysqli_real_escape_string($con, (int)$_GET['id']);
    $sName = mysqli_real_escape_string($con, trim($_REQUEST->sName));
    $email = mysqli_real_escape_string($con, $_REQUEST->email); 

    $sql = "UPDATE students SET sName ='$sName', email ='$email' WHERE sId='{$sId}' LIMIT 1 "; 

   
    if(mysqli_query($con,$sql)) {
        http_response_code(204);
    } else {
        return http_response_code(422);
    }
}




?>