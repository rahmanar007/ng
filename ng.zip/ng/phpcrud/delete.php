<?php 
require 'confiq.php';

//Deleting Student Details 

    $sId = $_GET['sId'];

$sql = "DELETE FROM students WHERE sId = '{$sId}'";



    if(mysqli_query($con,$sql)) {
        http_response_code(204);
    } else {
        return http_response_code(422);
    }


?>